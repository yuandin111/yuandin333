<script setup>
import { ref } from 'vue'

const props = defineProps({
  // 登录用户名，由 App.vue 传入
  user: { type: String, default: 'User' }
})
const emit = defineEmits(['logout'])

// ---------- 搜索（纯前端演示，接口位置已预留） ----------
const keyword = ref('')
const searching = ref(false)
const tip = ref('')
const hotTags = ['Vue 3', 'Spring Boot', 'MyBatis-Plus', '科技前沿', 'AI 助手']

const doSearch = () => {
  const kw = keyword.value.trim()
  if (!kw) {
    tip.value = '请输入搜索关键词'
    return
  }
  searching.value = true
  tip.value = ''
  // TODO: 接入后端检索接口（暂留前端演示逻辑）
  setTimeout(() => {
    searching.value = false
    tip.value = `演示环境：「${kw}」的检索接口待接入`
  }, 600)
}

// ---------- 静态内容 ----------
const menus = [
  { label: '首页', active: true },
  { label: '探索', active: false },
  { label: '数据看板', active: false },
  { label: '文档中心', active: false }
]

const panels = [
  { icon: '🚀', title: '快速入口', desc: '常用功能一键直达，减少操作路径，提升协作效率。' },
  { icon: '📊', title: '数据看板', desc: '实时汇聚核心指标，运行状态一屏掌握。' },
  { icon: '🛡️', title: '安全中心', desc: '账户安全、登录设备与权限体系统一管理。' }
]

const stats = [
  { label: 'CPU 占用', value: 86 },
  { label: '内存占用', value: 64 },
  { label: '网络吞吐', value: 42 }
]

const initial = () => (props.user || 'U').trim().charAt(0).toUpperCase()
</script>

<template>
  <!-- 科技风背景：网格 + 扫描线 -->
  <div class="tech-grid"></div>
  <div class="scanline"></div>

  <!-- ===== 顶部导航栏 ===== -->
  <header class="nav">
    <div class="logo">
      <span class="mark">⚡</span>
      <span class="name">智能门户</span>
      <span class="badge">TECH&nbsp;PORTAL</span>
    </div>

    <nav class="menu">
      <a v-for="(m, i) in menus" :key="i" href="#" :class="{ active: m.active }">{{ m.label }}</a>
    </nav>

    <div class="user-area">
      <span class="bell" title="通知">🔔</span>
      <span class="avatar">{{ initial() }}</span>
      <span class="uname">{{ user }}</span>
      <button class="logout" @click="emit('logout')">退出登录</button>
    </div>
  </header>

  <!-- ===== 主视觉区：欢迎语 + 搜索栏 ===== -->
  <main class="hero">
    <p class="eyebrow">// WELCOME BACK</p>
    <h1>欢迎回来，<span class="grad">{{ user }}</span></h1>
    <p class="sub">接入智能检索中枢，开启高效探索之旅</p>

    <div class="search" :class="{ focus: keyword }">
      <span class="icon">🔍</span>
      <input
        v-model="keyword"
        type="text"
        placeholder="搜索功能、文档、数据…"
        @keyup.enter="doSearch"
      />
      <button class="btn" :class="{ loading: searching }" @click="doSearch">
        <span v-if="!searching">搜 索</span>
        <span v-else class="spinner"></span>
      </button>
    </div>

    <div class="tags">
      <span class="tag-label">热门：</span>
      <button v-for="(t, i) in hotTags" :key="i" class="tag" @click="keyword = t">{{ t }}</button>
    </div>
    <p v-if="tip" class="tip">{{ tip }}</p>
  </main>

  <!-- ===== 内容区：功能面板 ===== -->
  <section class="content">
    <div v-for="(p, i) in panels" :key="i" class="panel">
      <div class="p-icon">{{ p.icon }}</div>
      <h3>{{ p.title }}</h3>
      <p>{{ p.desc }}</p>
      <span class="p-link">进入 →</span>
    </div>
  </section>

  <!-- ===== 系统状态（纯前端展示） ===== -->
  <section class="status">
    <div class="s-head">
      <span class="dot"></span>
      <span>系统运行状态</span>
      <span class="s-time">实时监测中</span>
    </div>
    <div class="s-bars">
      <div v-for="(s, i) in stats" :key="i" class="s-item">
        <span class="s-label">{{ s.label }}</span>
        <div class="s-track"><div class="s-fill" :style="{ width: s.value + '%' }"></div></div>
        <span class="s-value">{{ s.value }}%</span>
      </div>
    </div>
  </section>

  <footer class="foot">智能门户 · 前端演示页面 — 后端接口已保留，功能陆续接入</footer>
</template>

<style scoped>
/* ---------- 背景装饰 ---------- */
.tech-grid {
  position: fixed;
  inset: 0;
  z-index: 0;
  pointer-events: none;
  background-image:
    linear-gradient(rgba(42, 209, 255, 0.05) 1px, transparent 1px),
    linear-gradient(90deg, rgba(42, 209, 255, 0.05) 1px, transparent 1px);
  background-size: 44px 44px;
  -webkit-mask-image: radial-gradient(ellipse 90% 70% at 50% 30%, #000 30%, transparent 75%);
  mask-image: radial-gradient(ellipse 90% 70% at 50% 30%, #000 30%, transparent 75%);
}
.scanline {
  position: fixed;
  left: 0;
  right: 0;
  top: -20%;
  height: 140px;
  z-index: 0;
  pointer-events: none;
  background: linear-gradient(180deg, transparent, rgba(42, 209, 255, 0.07), transparent);
  animation: scan 7s linear infinite;
}
@keyframes scan {
  0% { top: -20%; }
  100% { top: 120%; }
}

/* ---------- 导航栏 ---------- */
.nav {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  z-index: 10;
  display: flex;
  align-items: center;
  justify-content: space-between;
  height: 64px;
  padding: 0 32px;
  background: rgba(13, 16, 39, 0.72);
  backdrop-filter: blur(14px);
  -webkit-backdrop-filter: blur(14px);
  border-bottom: 1px solid rgba(42, 209, 255, 0.18);
}
.logo {
  display: flex;
  align-items: center;
  gap: 10px;
  font-size: 17px;
  font-weight: 700;
  letter-spacing: 1px;
}
.logo .mark {
  width: 34px;
  height: 34px;
  display: grid;
  place-items: center;
  border-radius: 9px;
  font-size: 17px;
  background: linear-gradient(135deg, var(--c1), var(--c3));
  box-shadow: 0 0 16px rgba(42, 209, 255, 0.5);
}
.logo .name {
  background: linear-gradient(90deg, var(--c3), #ffffff);
  -webkit-background-clip: text;
  background-clip: text;
  color: transparent;
}
.logo .badge {
  font-size: 10px;
  font-weight: 600;
  letter-spacing: 2px;
  color: var(--c3);
  border: 1px solid rgba(42, 209, 255, 0.4);
  border-radius: 4px;
  padding: 2px 6px;
}

.menu {
  display: flex;
  gap: 4px;
}
.menu a {
  position: relative;
  padding: 8px 16px;
  color: var(--muted);
  text-decoration: none;
  font-size: 14px;
  border-radius: 8px;
  transition: color 0.25s, background 0.25s;
}
.menu a:hover {
  color: var(--text);
  background: rgba(42, 209, 255, 0.08);
}
.menu a.active {
  color: var(--text);
  background: rgba(42, 209, 255, 0.1);
}
.menu a.active::after {
  content: '';
  position: absolute;
  left: 16px;
  right: 16px;
  bottom: 2px;
  height: 2px;
  border-radius: 2px;
  background: var(--c3);
  box-shadow: 0 0 8px var(--c3);
}

.user-area {
  display: flex;
  align-items: center;
  gap: 12px;
  font-size: 13px;
}
.bell {
  cursor: pointer;
  font-size: 16px;
  opacity: 0.75;
  transition: opacity 0.2s, transform 0.2s;
}
.bell:hover {
  opacity: 1;
  transform: scale(1.15);
}
.avatar {
  width: 34px;
  height: 34px;
  display: grid;
  place-items: center;
  border-radius: 50%;
  font-weight: 700;
  font-size: 15px;
  color: #fff;
  background: linear-gradient(135deg, var(--c1), var(--c2));
  box-shadow: 0 0 14px rgba(106, 92, 255, 0.5);
}
.uname {
  color: var(--text);
  max-width: 120px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.logout {
  padding: 7px 14px;
  border: 1px solid var(--line);
  border-radius: 8px;
  background: transparent;
  color: var(--muted);
  cursor: pointer;
  font-size: 13px;
  transition: color 0.25s, border-color 0.25s, box-shadow 0.25s;
}
.logout:hover {
  color: #ff8fb1;
  border-color: rgba(255, 92, 168, 0.5);
  box-shadow: 0 0 12px rgba(255, 92, 168, 0.25);
}

/* ---------- 主视觉 + 搜索栏 ---------- */
.hero {
  position: relative;
  z-index: 2;
  max-width: 780px;
  margin: 0 auto;
  padding: 158px 24px 54px;
  text-align: center;
}
.eyebrow {
  font-size: 12px;
  letter-spacing: 4px;
  color: var(--c3);
  margin-bottom: 14px;
}
.hero h1 {
  font-size: 38px;
  font-weight: 700;
  letter-spacing: 1px;
}
.grad {
  background: linear-gradient(90deg, var(--c1), var(--c2), var(--c3));
  -webkit-background-clip: text;
  background-clip: text;
  color: transparent;
}
.sub {
  color: var(--muted);
  font-size: 15px;
  margin: 14px 0 38px;
}

.search {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 6px;
  border-radius: 16px;
  background: rgba(255, 255, 255, 0.06);
  border: 1px solid var(--line);
  transition: border-color 0.3s, box-shadow 0.3s;
}
.search:focus-within {
  border-color: rgba(42, 209, 255, 0.6);
  box-shadow: 0 0 0 4px rgba(42, 209, 255, 0.12), 0 0 32px rgba(42, 209, 255, 0.25);
}
.search .icon {
  padding-left: 12px;
  font-size: 15px;
}
.search input {
  flex: 1;
  min-width: 0;
  background: transparent;
  border: none;
  outline: none;
  color: var(--text);
  font-size: 15px;
  padding: 12px 8px;
}
.search input::placeholder {
  color: var(--muted);
}
.search .btn {
  display: grid;
  place-items: center;
  min-width: 96px;
  height: 44px;
  border: none;
  border-radius: 12px;
  cursor: pointer;
  font-size: 15px;
  font-weight: 600;
  color: #fff;
  letter-spacing: 2px;
  background: linear-gradient(135deg, var(--c1), var(--c3));
  box-shadow: 0 8px 20px rgba(42, 209, 255, 0.35);
  transition: transform 0.2s, box-shadow 0.25s;
}
.search .btn:hover {
  transform: translateY(-1px);
  box-shadow: 0 10px 28px rgba(42, 209, 255, 0.55);
}
.spinner {
  width: 18px;
  height: 18px;
  border: 2px solid rgba(255, 255, 255, 0.4);
  border-top-color: #fff;
  border-radius: 50%;
  animation: spin 0.7s linear infinite;
}
@keyframes spin {
  to { transform: rotate(360deg); }
}

.tags {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  justify-content: center;
  gap: 8px;
  margin-top: 18px;
  font-size: 13px;
}
.tag-label {
  color: var(--muted);
}
.tag {
  padding: 5px 12px;
  border: 1px solid var(--line);
  border-radius: 999px;
  background: rgba(255, 255, 255, 0.05);
  color: var(--muted);
  cursor: pointer;
  font-size: 12px;
  transition: color 0.2s, border-color 0.2s, box-shadow 0.2s;
}
.tag:hover {
  color: var(--c3);
  border-color: rgba(42, 209, 255, 0.5);
  box-shadow: 0 0 10px rgba(42, 209, 255, 0.2);
}
.tip {
  margin-top: 14px;
  font-size: 12px;
  color: var(--c3);
  min-height: 16px;
}

/* ---------- 功能面板（HUD 边角） ---------- */
.content {
  position: relative;
  z-index: 2;
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 22px;
  max-width: 1080px;
  margin: 0 auto;
  padding: 0 24px;
}
.panel {
  position: relative;
  padding: 26px 24px;
  background: var(--card);
  border: 1px solid var(--line);
  border-radius: 16px;
  backdrop-filter: blur(10px);
  -webkit-backdrop-filter: blur(10px);
  transition: transform 0.3s, border-color 0.3s, box-shadow 0.3s;
}
.panel::before,
.panel::after {
  content: '';
  position: absolute;
  width: 16px;
  height: 16px;
  opacity: 0.75;
  transition: opacity 0.3s;
}
.panel::before {
  top: -1px;
  left: -1px;
  border-top: 2px solid var(--c3);
  border-left: 2px solid var(--c3);
  border-top-left-radius: 16px;
}
.panel::after {
  bottom: -1px;
  right: -1px;
  border-bottom: 2px solid var(--c3);
  border-right: 2px solid var(--c3);
  border-bottom-right-radius: 16px;
}
.panel:hover {
  transform: translateY(-4px);
  border-color: rgba(42, 209, 255, 0.45);
  box-shadow: 0 16px 40px rgba(0, 0, 0, 0.4), 0 0 22px rgba(42, 209, 255, 0.12);
}
.panel:hover::before,
.panel:hover::after {
  opacity: 1;
}
.p-icon {
  width: 46px;
  height: 46px;
  display: grid;
  place-items: center;
  border-radius: 12px;
  font-size: 22px;
  background: rgba(42, 209, 255, 0.1);
  border: 1px solid rgba(42, 209, 255, 0.25);
  margin-bottom: 16px;
}
.panel h3 {
  font-size: 16px;
  font-weight: 600;
  margin-bottom: 8px;
}
.panel p {
  font-size: 13px;
  line-height: 1.7;
  color: var(--muted);
}
.p-link {
  display: inline-block;
  margin-top: 14px;
  font-size: 13px;
  color: var(--c3);
  cursor: pointer;
  transition: letter-spacing 0.25s;
}
.p-link:hover {
  letter-spacing: 1px;
}

/* ---------- 系统状态条 ---------- */
.status {
  position: relative;
  z-index: 2;
  max-width: 1080px;
  margin: 22px auto 0;
  padding: 20px 26px;
  background: var(--card);
  border: 1px solid var(--line);
  border-radius: 16px;
  backdrop-filter: blur(10px);
  -webkit-backdrop-filter: blur(10px);
}
.s-head {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 13px;
  font-weight: 600;
  margin-bottom: 16px;
}
.s-head .dot {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: #4fe39a;
  box-shadow: 0 0 8px #4fe39a;
  animation: blink 1.6s ease-in-out infinite;
}
@keyframes blink {
  50% { opacity: 0.35; }
}
.s-time {
  margin-left: auto;
  font-size: 12px;
  font-weight: 400;
  color: var(--muted);
}
.s-bars {
  display: grid;
  gap: 12px;
}
.s-item {
  display: grid;
  grid-template-columns: 72px 1fr 44px;
  align-items: center;
  gap: 12px;
  font-size: 12px;
}
.s-label {
  color: var(--muted);
}
.s-track {
  height: 8px;
  border-radius: 4px;
  background: rgba(255, 255, 255, 0.08);
  overflow: hidden;
}
.s-fill {
  height: 100%;
  border-radius: 4px;
  background: linear-gradient(90deg, var(--c1), var(--c3));
  box-shadow: 0 0 10px rgba(42, 209, 255, 0.4);
}
.s-value {
  color: var(--c3);
  text-align: right;
}

/* ---------- 页脚 ---------- */
.foot {
  position: relative;
  z-index: 2;
  text-align: center;
  font-size: 12px;
  color: var(--muted);
  padding: 40px 24px 28px;
}

/* ---------- 响应式 ---------- */
@media (max-width: 860px) {
  .menu { display: none; }
  .content { grid-template-columns: 1fr; }
  .hero h1 { font-size: 28px; }
  .hero { padding-top: 120px; }
  .uname { display: none; }
}
</style>
